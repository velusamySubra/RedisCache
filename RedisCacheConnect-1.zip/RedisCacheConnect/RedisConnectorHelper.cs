﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;
using StackExchange.Redis;

namespace RedisCacheConnect
{


    public class RedisConnectorHelper
    {
        static RedisConnectorHelper()
        {
            try
            {
                RedisConnectorHelper.lazyConnection = new Lazy<ConnectionMultiplexer>(() =>
                {
                    // return ConnectionMultiplexer.Connect("10.110.11.251:6379");
                    // return ConnectionMultiplexer.Connect("10.50.8.33:7000,ssl=true,abortConnect=false,allowAdmin=true");
                    return ConnectionMultiplexer.Connect("EVM-APPREDINT01:7000");
                });
            }
            catch {
                Exception ex = null;
                string ms = ex.Message; }
        }

        private static Lazy<ConnectionMultiplexer> lazyConnection;

        public static ConnectionMultiplexer Connection
        {
            get
            {
                return lazyConnection.Value;
            }
        }
    }
}