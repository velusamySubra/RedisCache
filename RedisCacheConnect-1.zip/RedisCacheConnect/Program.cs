﻿using RedisCacheConnect;

class Program
{
    static void Main(string[] args)
    {
        var program = new Program();

        Console.WriteLine("Saving random data in cache");
        program.SaveDataToRedis();

        Console.WriteLine("Reading data from cache");
        program.ReadData();

        Console.ReadLine();
    }

    public void ReadData()
    {
        var cache = RedisConnectorHelper.Connection.GetDatabase();
       
            var value = cache.StringGet($"Status");
            Console.WriteLine($"val={value}");
        
    }

    public void SaveDataToRedis()
    {
        
        var rnd = new Random();
        var cache = RedisConnectorHelper.Connection.GetDatabase();

      cache.StringSet("Status", "Good Day");

    }
}